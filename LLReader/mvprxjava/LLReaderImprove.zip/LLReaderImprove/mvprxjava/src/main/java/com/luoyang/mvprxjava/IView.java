package com.luoyang.mvprxjava;

import android.content.Context;

/**
 * package: com.luoyang.mvprxjava
 * created by luoyang
 * QQ:1845313665
 * on 2018/11/3
 */
public interface IView {
    public Context getContext();
}
