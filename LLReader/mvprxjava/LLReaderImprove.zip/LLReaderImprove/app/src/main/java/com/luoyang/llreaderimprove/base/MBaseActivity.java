package com.luoyang.llreaderimprove.base;


import com.luoyang.mvprxjava.IPresenter;
import com.luoyang.mvprxjava.impl.BaseActivity;


/**
 * package: com.luoyang.llreader.base
 * created by luoyang
 * QQ:1845313665
 * on 2018/11/3
 */

public abstract class MBaseActivity<P extends IPresenter> extends BaseActivity<P> {

    @Override
    protected void onResume() {
        super.onResume();
        //MobclickAgent.onResume(this);
    }


    protected void onPause() {
        super.onPause();
       // MobclickAgent.onPause(this);
    }
}

